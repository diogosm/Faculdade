#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#define MAX 37      //37 eh um primo...por isso escolhi ele...

typedef struct noh{
	struct noh *prox;
	char nome[101];
} tipoNo;

typedef tipoNo *hash[MAX];

/*********************************funcoes**********************************/

int func_hash(char vet[]){        //função básica do slide...somente para comparacao com a que eu criei mais embaixo...
	int x = strlen(vet);
	return x%MAX;
}

int func_hash2(char vet[]){
	int h = (int)vet[0] + 5*((int)vet[1] + (int)vet[2]);
	return h%MAX;
}

/**************************************************************************/



void inserir(hash h, char nome[]){
	int ha = func_hash(nome);    //para usar a segunda funcão basta colocar func_hash2(nome);
	tipoNo *novo;
	novo = (tipoNo *)malloc(sizeof(tipoNo));	
	strcpy(novo->nome, nome);
	novo->prox = h[ha];
	h[ha] = novo;	
}



void inicia(hash h){
	int i=0;
	while(i < MAX){
		h[i] = NULL;
		i++;
	}
}
	

/*************************************************************************/


int main(int argc, char **argv){
	
	hash hash;           //declaracao do hash.  hash que é do tipo vetor hash...igual declarado na linha 12
	inicia(hash);
	if(argc!=2){         //verifica se o numero de argumentos foi correto...
		exit(1);
	}

	FILE *fp;
	fp = fopen(argv[1], "r+");
	if(fp == NULL){
		exit(1);
	}
	char nome[81];
	inicia(hash);
	while((fgets(nome, 81, fp))!=NULL){        //inserção a partir do arquivo
		inserir(hash, nome);
	}
		int x = 0;
		tipoNo *aux;
			while(x<MAX){             //loop para mostrar o hash...
				aux = hash[x];
				while(aux!=NULL){
					printf("-- %d -- %s --", x, aux->nome);
					aux = aux->prox;
				}
				x++;
			}
				





	return 0;
}
